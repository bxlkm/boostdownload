.. Copyright David Abrahams 2006. Distributed under the Boost
.. Software License, Version 1.0. (See accompanying
.. file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

Prepare to Use a Boost Library Binary
=====================================

If you want to use any of the separately-compiled Boost libraries,
you'll need to acquire library binaries.

